package com.sdsu.hearingsciences.goldilocks.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.sdsu.hearingsciences.goldilocks.R;
import com.sdsu.hearingsciences.goldilocks.fragments.HomeFragment;
import com.sdsu.hearingsciences.goldilocks.fragments.ManualAdjustFragment;
import com.sdsu.hearingsciences.goldilocks.fragments.ResearcherPresetsFragment;

public class HomeActivity extends AppCompatActivity implements HomeFragment.OnHomeFragmentInteractionListener,
        ManualAdjustFragment.OnManualAdjustInteraction, ResearcherPresetsFragment.OnResearcherPresetsInteractionListener{

    Toolbar toolbar;
    NavigationView navigationView;
    DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        navigationView = (NavigationView) findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            // This method will trigger on item Click of navigation menu
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                if(menuItem.isChecked()) menuItem.setChecked(false);
                else menuItem.setChecked(true);
                drawerLayout.closeDrawers();
                switch (menuItem.getItemId()){
                    case R.id.changeListener:
                        loadFragment(HomeFragment.newInstance());
                        return true;
                    case R.id.manualAdjust:
                        loadFragment(ManualAdjustFragment.newInstance());
                        return true;
                    case R.id.researcherPresets:
                        loadFragment(ResearcherPresetsFragment.newInstance());
                        return true;
                    default:
                        Toast.makeText(getApplicationContext(),"Somethings Wrong", Toast.LENGTH_SHORT).show();
                        return true;
                }
            }
        });
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer);
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.openDrawer, R.string.closeDrawer){
            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
            }
            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
            }
        };
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

    }


    private void loadFragment(Fragment fragment){
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.common_container, fragment).commit();

    }


    @Override
    public void onFragmentInteraction(Uri uri) {

    }


    @Override
    public void onListenerSelfAdjust(String currentTesterId, String currentListenerName) {
        SharedPreferences sharedPreferences = getSharedPreferences("Tester", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("CurrentTesterId",currentTesterId);
        editor.apply();

        Intent selfAdjust = new Intent(this, SelfAdjustmentActivity.class);
        startActivity(selfAdjust);
    }

    @Override
    public void onExistingListener() {
        Intent readFile = new Intent(HomeActivity.this, GoogleDriveHelper.class);
        startActivity(readFile);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);

        return true;
    }
}
