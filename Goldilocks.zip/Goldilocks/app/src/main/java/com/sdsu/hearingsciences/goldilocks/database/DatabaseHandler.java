package com.sdsu.hearingsciences.goldilocks.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by Deepak on 6/19/2017.
 */

public class DatabaseHandler extends SQLiteOpenHelper {

    private static final String TAG = "DatabaseHelper";
    private static final String DATABASE_NAME = "android_halo.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(DBContract.CREATE_TABLE_JOBS_APPLIED);
    }

    public boolean checkTesterId(String testerId){
        String query = "Select * from " + DBContract.Tester.TABLE_NAME +
                " where "  +  DBContract.Tester.COLUMN_TESTER_ID + " = '" + testerId + "'";
        String tester = "";
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor result = sqLiteDatabase.rawQuery(query,null);
        while (result.moveToNext()) {
            tester = result.getString(result.getColumnIndex(DBContract.Tester.COLUMN_TESTER_ID));
        }
        result.close();
        if(tester.equals(testerId)) {
            return true;
        }
        else {
            storeTesterId(testerId);
            return false;
        }
    }


    private void storeTesterId(String testerId){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DBContract.Tester.COLUMN_TESTER_ID, testerId);
        try {
            db.insert(DBContract.Tester.TABLE_NAME,null,values);
        } catch (SQLiteConstraintException e) {
            Log.i(TAG,"Existing data");
        }
    }


    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
