package com.sdsu.hearingsciences.goldilocks.database;

import android.provider.BaseColumns;

/**
 * Created by Deepak on 6/19/2017.
 */

public class DBContract {

    static class Tester implements BaseColumns {
        static String TABLE_NAME = "Tester";
        static String COLUMN_TESTER_ID = "Tester_Id";
    }

    static final String CREATE_TABLE_JOBS_APPLIED =
            "CREATE TABLE IF NOT EXISTS " +
                    Tester.TABLE_NAME + " (" +
                    Tester._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    Tester.COLUMN_TESTER_ID + " TEXT)";
}
