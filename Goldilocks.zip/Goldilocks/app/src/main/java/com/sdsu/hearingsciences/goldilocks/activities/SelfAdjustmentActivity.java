package com.sdsu.hearingsciences.goldilocks.activities;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.drive.Drive;
import com.sdsu.hearingsciences.goldilocks.R;
import com.sdsu.hearingsciences.goldilocks.googledrivetasks.*;

import org.w3c.dom.Text;

public class SelfAdjustmentActivity extends GoogleDriveBaseActivity implements View.OnClickListener{

    private static final String TAG = "SelfAdjustmentActivity";

    LinearLayout mFullnessControl ;
    LinearLayout mLoudnessControl ;
    LinearLayout mCrispnessControl;
    Button mFullnessIncrease, mFullnessDecrease, mFullnessOkay;
    Button mLoudnessIncrease, mLoudnessDecrease, mLoudnessOkay;
    Button mCrispnessIncrease, mCrispnessDecrease, mCrispnessOkay;
    TextView mMessage;

    Integer fullness = 0 , crispness = 0 , loudness = 0;
    int loudnessIteration = 0;
    Integer maxLoudness, minLoudness = 0, maxFullness, minFullness = 0, maxCrispness = 7, minCrispness = 0;
    Integer stepSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_self_adjustment);

        Toolbar toolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(toolbar);

        setUpMaxValues(1);

        // Android widgets
        mFullnessControl = (LinearLayout) findViewById(R.id.fullness_control);
        mLoudnessControl = (LinearLayout) findViewById(R.id.loudness_control);
        mCrispnessControl = (LinearLayout) findViewById(R.id.crispness_control);
        mMessage = (TextView) findViewById(R.id.message);
        mFullnessIncrease = (Button) findViewById(R.id.fullness_increase);
        mFullnessDecrease = (Button) findViewById(R.id.fullness_decrease);
        mFullnessOkay = (Button) findViewById(R.id.fullness_ok);
        mCrispnessIncrease = (Button) findViewById(R.id.crispness_increase);
        mCrispnessDecrease = (Button) findViewById(R.id.crispness_decrease);
        mCrispnessOkay = (Button) findViewById(R.id.crispness_ok);
        mLoudnessIncrease = (Button) findViewById(R.id.loudness_increase);
        mLoudnessDecrease = (Button) findViewById(R.id.loudness_decrease);
        mLoudnessOkay = (Button) findViewById(R.id.loudness_ok);

        // setting on click listeners
        mFullnessIncrease.setOnClickListener(this);
        mFullnessDecrease.setOnClickListener(this);
        mFullnessOkay.setOnClickListener(this);
        mCrispnessIncrease.setOnClickListener(this);
        mCrispnessDecrease.setOnClickListener(this);
        mCrispnessOkay.setOnClickListener(this);
        mLoudnessIncrease.setOnClickListener(this);
        mLoudnessDecrease.setOnClickListener(this);
        mLoudnessOkay.setOnClickListener(this);

       Intent listenerInstructionIntent = new Intent(this, GetListenerInstructions.class);
       startActivityForResult(listenerInstructionIntent, 10);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case 10:
                if(resultCode == RESULT_OK){
                    showInstructions(data.getStringExtra("Instructions"));
                }
        }
    }

    protected void showInstructions(String instructions) {
        // Inflate the about message contents
        View messageView = getLayoutInflater().inflate(R.layout.instructions, null, false);
        Button mStart = (Button) messageView.findViewById(R.id.start);
        TextView ins = (TextView) messageView.findViewById(R.id.general_instructions);
        ins.setText(instructions);
        Animation startAnimation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.blink);
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(messageView);
        builder.setCancelable(false);
        final AlertDialog dialog = builder.create();
        dialog.show();
        mStart.startAnimation(startAnimation);
        mStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               dialog.dismiss();
            }
        });
    }

    @Override
    public void onClick(View view) {

        int mCLickedButtonId = view.getId();

        switch(mCLickedButtonId){
            case R.id.fullness_increase:
                if(fullness <= maxFullness) fullness++;
                else {
                    showAlerts(getResources().getString(R.string.maxReached));
                    mFullnessIncrease.setEnabled(false);
                }
                if(fullness > minFullness) mFullnessDecrease.setEnabled(true);

                break;
            case R.id.fullness_decrease:
                if(fullness > minFullness){
                    fullness--;
                } else {
                    mFullnessDecrease.setEnabled(false);
                    showAlerts(getResources().getString(R.string.minReached));
                }
                if(fullness <= maxFullness){
                    mFullnessIncrease.setEnabled(true);
                }
                break;
            case R.id.fullness_ok:
                Log.i(TAG, "Fullness value : " +fullness);
                mLoudnessControl.setVisibility(View.VISIBLE);
                mCrispnessControl.setVisibility(View.VISIBLE);
                mFullnessOkay.setEnabled(false);
                mLoudnessOkay.setEnabled(false);
                mCrispnessOkay.setEnabled(false);
                mMessage.setText(getResources().getText(R.string.finalAdjustInstruction));
                break;
            case R.id.loudness_increase:
                if(loudness <= maxLoudness){
                    loudness++;
                } else {
                    showAlerts(getResources().getString(R.string.maxReached));
                }
                if(loudness > minLoudness) {
                    mLoudnessDecrease.setEnabled(true);
                }
                break;
            case R.id.loudness_decrease:
                if(loudness > minLoudness) loudness--;
                else {
                    showAlerts(getResources().getString(R.string.minReached));
                    mLoudnessDecrease.setEnabled(false);
                }
                if(loudness <= maxLoudness) {
                    mLoudnessIncrease.setEnabled(true);
                }
                break;
            case R.id.loudness_ok:
                if(loudnessIteration==0){
                    mLoudnessControl.setVisibility(View.INVISIBLE);
                    mCrispnessControl.setVisibility(View.VISIBLE);
                    mMessage.setText(getResources().getString(R.string.crispnessInstruction));
                    loudnessIteration++;
                    Log.i(TAG, "Loudness value : "  + loudness);
                } else {
                    loudnessIteration = 0;
                    mLoudnessControl.setVisibility(View.INVISIBLE);
                    mFullnessControl.setVisibility(View.VISIBLE);
                    mMessage.setText(getResources().getString(R.string.fullnessInstruction));
                    Log.i(TAG, "Loudness value : "  + loudness);
                }
                break;
            case R.id.crispness_increase:
                if(crispness <= maxCrispness) crispness++;
                else {
                    showAlerts(getResources().getString(R.string.maxReached));
                    mCrispnessIncrease.setText(getResources().getString(R.string.maxReached));
                    mCrispnessIncrease.setEnabled(false);
                }
                if(crispness > minCrispness) {
                    mCrispnessDecrease.setEnabled(true);
                }
                break;
            case R.id.crispness_decrease:
                if(crispness > minCrispness) crispness--;
                else {
                    mCrispnessDecrease.setEnabled(false);
                    showAlerts(getResources().getString(R.string.minReached));
                }
                if(crispness <= maxCrispness){
                    mCrispnessIncrease.setEnabled(true);
                }
                break;
            case R.id.crispness_ok:
                Log.i(TAG, "Crispness Value : "+crispness);
                mCrispnessControl.setVisibility(View.INVISIBLE);
                mLoudnessControl.setVisibility(View.VISIBLE);
                mMessage.setText(getResources().getString(R.string.loudnessReadjustInstruction));
                break;
        }

    }

    private void showAlerts(String alterMessage){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                this);
        alertDialogBuilder.setTitle("Caution...!!");
        alertDialogBuilder
                .setMessage(alterMessage)
                .setCancelable(true)
                .setPositiveButton("Okay",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void setUpMaxValues(Integer stepSize){
        switch (stepSize){
            case 1:
                maxFullness = 10;
                maxLoudness = 40;
                break;
            case 2:
                maxFullness = 5;
                maxLoudness = 20;
                break;
            case 3 :
                maxFullness = 3;
                maxLoudness = 39;
                break;
            case 4: maxFullness = 2;
                maxLoudness = 10;
                break;
            case 5:
                maxFullness = 2;
                maxLoudness = 8;
                break;

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        switch (item.getItemId()){
            case R.id.home:
                finish();
                break;

        }

        return true;
    }
}
